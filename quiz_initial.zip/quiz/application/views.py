from django.shortcuts import render
from django.contrib import messages
from .models import *


# Create your views here.
def home(request):
    return render(request, 'application/home.html')


def rating(request):
    return render(request, 'application/rating.html')


def calc(request):
    global var_fe, var_ds
    if request.method == 'GET':
        request.session['php'] = int(request.GET.get('p'))
        request.session['html'] = int(request.GET.get('h'))
        request.session['css'] = int(request.GET.get('c'))
        request.session['wpress'] = int(request.GET.get('w'))
        request.session['bstrap'] = int(request.GET.get('b'))
        request.session['r'] = int(request.GET.get('r'))
        request.session['py'] = int(request.GET.get('py'))
        request.session['stat'] = int(request.GET.get('stat'))
        request.session['mcl'] = int(request.GET.get('ml'))
        var_fe = request.session['php'] + request.session['html'] + request.session['css'] + request.session['wpress'] + \
                 request.session['bstrap']
        var_ds = request.session['r'] + request.session['py'] + request.session['stat'] + request.session['mcl']
        if var_fe < 20 and var_ds < 16:
            messages.success(request, "You need to improve your skills")
            return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
        if var_fe < 20 and var_ds >= 16 and var_fe < var_ds:
            if request.session['r'] >= 4 and request.session['py'] >= 5 and request.session['stat'] >= 4 and \
                    request.session['mcl'] >= 4:
                messages.success(request, "You can be a Data Scientist")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
            else:
                messages.success(request, "You need to improve your Data Science skills")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
        if var_ds < 16 and var_fe >= 20 and var_ds < var_fe:
            if request.session['html'] >= 5 and request.session['css'] >= 5 and request.session['wpress'] >= 4 and \
                    request.session['bstrap'] >= 5 and request.session['php'] >= 4:
                messages.success(request, "You can be a FrontEnd Developer")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
            if request.session['php'] >= 5 and request.session['html'] >= 4 and request.session['css'] >= 4 and \
                    request.session['wpress'] >= 5 and request.session['bstrap'] >= 4:
                messages.success(request, "You can be a BackEnd Developer")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
            if request.session['php'] >= 5 and request.session['html'] >= 5 and request.session['css'] >= 5 and \
                    request.session['wpress'] >= 5 and request.session['bstrap'] >= 5:
                messages.success(request, "You can be a Good Web Developer")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
            else:
                messages.success(request, "You need to improve your Web Development skills")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
        if 16 <= var_ds < var_fe and var_fe >= 20:
            if request.session['html'] >= 5 and request.session['css'] >= 5 and request.session['wpress'] >= 4 and \
                    request.session['bstrap'] >= 5 and request.session['php'] >= 4:
                messages.success(request, "You can be a FrontEnd Developer")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
            if request.session['php'] >= 5 and request.session['html'] >= 4 and request.session['css'] >= 4 and \
                    request.session['wpress'] >= 5 and request.session['bstrap'] >= 4:
                messages.success(request, "You can be a BackEnd Developer")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
            if request.session['php'] >= 5 and request.session['html'] >= 5 and request.session['css'] >= 5 and \
                    request.session['wpress'] >= 5 and request.session['bstrap'] >= 5:
                messages.success(request, "You can be a Good Web Developer")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
            else:
                messages.success(request, "You need to improve your Web Development skills")
                return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
        if 20 <= var_fe < var_ds and var_ds >= 16:
            messages.success(request, "You can be a Data Scientist")
            return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})
        if var_ds == var_fe:
            messages.success(request, "You can be a Data Scientist or Web Developer")
            return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})

        else:
            pass
    return render(request, 'application/result.html', {'score_fe': var_fe, 'score_ds': var_ds})


def test(request):
    questions_fe = Development.objects.all()
    questions_ds = DataScience.objects.all()
    return render(request, 'application/test.html', {'questions_fe': questions_fe, 'questions_ds': questions_ds})


def result(request):
    questions_fe = Development.objects.all()
    questions_ds = DataScience.objects.all()
    total_fe = get_scorefe(request, questions_fe)
    total_ds = get_scoreds(request, questions_ds)
    if total_ds <= 8 and total_fe <= 10:
        messages.success(request, "You need to improve your skills")
        return render(request, 'application/result.html', {'score_fe': total_fe, 'score_ds': total_ds})
    if total_fe <= 10 and total_ds > 8:
        messages.success(request, "You can be a Data Scientist")
        return render(request, 'application/result.html', {'score_fe': total_fe, 'score_ds': total_ds})
    if total_fe > 10 and total_ds <= 8:
        messages.success(request, "You can be a Web Developer")
        return render(request, 'application/result.html', {'score_fe': total_fe, 'score_ds': total_ds})
    if total_fe > total_ds > 8:
        messages.success(request, "You can be a Web Developer")
        return render(request, 'application/result.html', {'score_fe': total_fe, 'score_ds': total_ds})
    if total_ds > total_fe > 10:
        messages.success(request, "You can be a Data Scientist")
        return render(request, 'application/result.html', {'score_fe': total_fe, 'score_ds': total_ds})


def get_scorefe(request, questions_fe):
    total_fe = 0
    for i in questions_fe:
        answer = i.answer
        user_answer = request.POST.get(str(i.id))
        if user_answer == answer:
            total_fe += 1
    return total_fe


def get_scoreds(request, questions_ds):
    total_ds = 0
    for j in questions_ds:
        answer = j.answer
        user_answer = request.POST.get(str(j.answer))
        if user_answer == answer:
            total_ds += 1
    return total_ds
