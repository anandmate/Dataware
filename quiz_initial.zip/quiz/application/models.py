from django.db import models

# Create your models here.
class Development(models.Model):
    category = models.CharField(max_length=20)
    question = models.CharField(max_length=150)
    option1 = models.CharField(max_length=50)
    option2 = models.CharField(max_length=50)
    option3 = models.CharField(max_length=50)
    option4 = models.CharField(max_length=50)
    answer = models.CharField(max_length=50)

    class Meta:
        db_table = 'web_development'

    def __str__(self):
        return self.category


class DataScience(models.Model):
    category = models.CharField(max_length=20)
    question = models.CharField(max_length=150)
    option1 = models.CharField(max_length=50)
    option2 = models.CharField(max_length=50)
    option3 = models.CharField(max_length=50)
    option4 = models.CharField(max_length=50)
    answer = models.CharField(max_length=50)

    class Meta:
        db_table = 'data_science'

    def __str__(self):
        return self.category